<h3>Etiquetas de <?php the_title() ?>:
<?php 
  //Lista de etiquetas
	
  the_tags('<ul class="list-inline"><li><span class="label label-default">','</span></li><li><span class="label label-default">','</span></li></ul>'); 
?>

</h3>